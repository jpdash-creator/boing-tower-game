"""
    Copyright(C) 2026 Altom Consulting
"""

from alttester.commands.AltTesterCommands import *
from alttester.commands.FindObjects import *
from alttester.commands.InputActions import *
from alttester.commands.ObjectCommands import *
from alttester.commands.UnityCommands import *
from alttester.commands.get_png_screenshot import GetPNGScreenshot
from alttester.commands.get_server_version import GetServerVersion
from alttester.commands.get_static_property import GetStaticProperty
from alttester.commands.set_static_property import SetStaticProperty
from alttester.commands.Notifications import *
