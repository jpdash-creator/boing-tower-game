"""
    Copyright(C) 2026 Altom Consulting
"""

from alttester.commands.FindObjects.find_object_which_contains import *
from alttester.commands.FindObjects.find_object import *
from alttester.commands.FindObjects.find_objects import *
from alttester.commands.FindObjects.find_objects_which_contains import *
from alttester.commands.FindObjects.wait_for_object import *
from alttester.commands.FindObjects.wait_for_object_to_not_be_present import *
from alttester.commands.FindObjects.wait_for_object_which_contains import *
from alttester.commands.FindObjects.find_object_at_coordinates import *
from alttester.commands.FindObjects.wait_for_component_property import *
from alttester.commands.FindObjects.wait_for_visual_element_property import *
